﻿This is a work in progress!

Helpful information:

(CTRL+Left Click on link to open in your browser)
Bannerlord Modding Documentation:   https://docs.bannerlordmodding.com/
Harmony Patching Documentation:     https://harmony.pardeike.net/articles/patching.html
TaleWorlds Modding Forums:          https://forums.taleworlds.com/index.php?pages/modding/
Mount and Blade Discord:            https://discordapp.com/invite/mountandblade
TW Forum - Modding Discord:         https://discordapp.com/invite/ykFVJGQ