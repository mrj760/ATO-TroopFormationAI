﻿using System.Collections.Generic;
using TaleWorlds.MountAndBlade;

namespace RBMAI
{
    public static class AgentPostures
    {
            public static Dictionary<Agent, Posture> values = new Dictionary<Agent, Posture> { };
            public static PostureVisualLogic postureVisual = null;
    }
}
